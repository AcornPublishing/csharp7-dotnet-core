﻿using System;

namespace Ch01_WelcomeDotNetCore
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Welcome, .NET Core!");
        }
    }
}