class MyApp { static void Main() {
System.Console.WriteLine("Hello, C#!"); } }