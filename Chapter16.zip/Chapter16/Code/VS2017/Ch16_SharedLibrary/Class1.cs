﻿using System.Collections.Specialized;

namespace Ch16_SharedLibrary
{
    public class Class1
    {
        public NameValueCollection stuff;
    }
}
