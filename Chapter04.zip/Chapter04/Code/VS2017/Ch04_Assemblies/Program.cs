﻿using System;
using System.Xml.Linq;

namespace Ch04_Assemblies
{
    class Program
    {
        static void Main(string[] args)
        {
            var doc = new XDocument();
            int age = 12;
        }
    }
}