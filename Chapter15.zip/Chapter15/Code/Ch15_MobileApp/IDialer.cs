﻿namespace Ch15_MobileApp
{
	public interface IDialer
	{
		bool Dial(string number);
	}
}
