﻿using Xamarin.Forms;

namespace Ch15_MobileApp
{
	public partial class Ch15_MobileAppPage : ContentPage
	{
		public Ch15_MobileAppPage()
		{
			InitializeComponent();
		}
	}
}
