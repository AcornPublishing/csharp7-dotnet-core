﻿using System;

namespace Ch05_Calculator
{
    public class Calculator
    {
        public double Add(double a, double b)
        {
            return a + b;
        }
    }
}
